# Baltā Saule — landing page

Next.js 15 (App Router) · TypeScript · Tailwind CSS v4 · Framer Motion · Lucide React

## Palaišana

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # produkcijas būvējums
npm start
```

## Struktūra

```
app/
  layout.tsx       RootLayout: fonti, metadata, JSON-LD
  page.tsx         vienīgā lapa — visas sadaļas pēc kārtas
  globals.css      Tailwind v4 tēma (krāsas, fonti)
  robots.ts, sitemap.ts, icon.svg
components/
  Header.tsx       navigācija ar anchor saitēm
  Footer.tsx
  sections/        Hero, Services, About, Celebrations, Interlude, Stays, Kitchen, Gallery, Contact
  ui/              Button, Reveal, MotionProvider
lib/data.ts        viss saturs: kontakti, navigācija, attēli, ēdienkarte, galerija
public/images/     fotogrāfijas
```

## Sadaļu ID

`#sakums` · `#par-mums` · `#svinibas` · `#naktsmitnes` · `#omites-virtuve` · `#galerija` · `#kontakti`

## Satura rediģēšana

Kontakti, domēns, cenas un teksti — `lib/data.ts`.
