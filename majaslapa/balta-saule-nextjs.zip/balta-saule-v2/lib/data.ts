/** Viss lapas saturs vienuviet. Kontaktus, cenas un tekstus rediģējiet šeit. */

export type Img = { src: string; alt: string; pos?: string };

export const site = {
  name: "Baltā Saule",
  url: "https://www.baltasaule.lv",
  locale: "lv_LV",
  tagline: "Atpūta pie jūras · Svinības · Omītes virtuve",
  description:
    "Mājīga vieta, kur jūras tuvums, gardi ēdieni un skaisti svētki kļūst par neaizmirstamām atmiņām.",
  seoDescription:
    "Baltā Saule — ģimenes viesu nams dažu soļu attālumā no jūras. Mājīgas naktsmītnes, svinību zāle līdz 40 viesiem, pirts, kubls un Omītes virtuves banketi kāzām, jubilejām un kristībām.",
} as const;

export const contact = {
  phone: "+371 20 000 000",
  phoneHref: "tel:+37120000000",
  email: "info@baltasaule.lv",
  facebook: "https://www.facebook.com/",
  address: "Baltā Saule, Latvija",
  mapsQuery: "Baltā Saule viesu nams",
  hours: [
    { days: "Pirmdiena – Piektdiena", time: "9:00 – 20:00" },
    { days: "Sestdiena – Svētdiena", time: "10:00 – 18:00" },
  ],
  hoursNote: "Pasākumi — pēc iepriekšējas vienošanās",
} as const;

export const navItems = [
  { label: "Sākums", href: "#sakums" },
  { label: "Par mums", href: "#par-mums" },
  { label: "Svinības", href: "#svinibas" },
  { label: "Naktsmītnes", href: "#naktsmitnes" },
  { label: "Omītes virtuve", href: "#omites-virtuve" },
  { label: "Galerija", href: "#galerija" },
  { label: "Kontakti", href: "#kontakti" },
] as const;

export const images = {
  hero: { src: "/images/hero.jpg", alt: "Baltās Saules koka namiņš ar verandu zaļumu ieskautā teritorijā" },
  about: { src: "/images/about.jpg", alt: "Viesi pie ziediem rotātās Baltās Saules ieejas" },
  flowers: { src: "/images/flowers.jpg", alt: "Baltās Saules zīme starp krāšņiem ziedu podiem" },
  veranda: { src: "/images/veranda.jpg", alt: "Veranda ar ziediem un viesiem" },
  wedding: { src: "/images/wedding.jpg", alt: "Viesi baltās drēbēs svinībās dārzā" },
  tubSwing: { src: "/images/tub-swing.jpg", alt: "Kubls un šūpuļkrēsls atpūtas terasē" },
  pies: { src: "/images/pies.jpg", alt: "Mājās cepti pīrāgi no Omītes virtuves" },
  hall: { src: "/images/hall.jpg", alt: "Svinību zāle ar garu, klātu svētku galdu" },
  table: { src: "/images/table.jpg", alt: "Svētku galds ar ziediem, uzkodām un dzērieniem" },
  decor: { src: "/images/decor.jpg", alt: "Svētku dekori ar lampiņām un sausziediem" },
  guests: { src: "/images/celebration-guests.jpg", alt: "Viesi svinībās Baltās Saules zālē" },
  balcony: { src: "/images/balcony.jpg", alt: "Balkons ar puķu podiem un skatu uz zaļumiem" },
  room: { src: "/images/room.jpg", alt: "Gaiša atpūtas telpa ar koka grīdu un dīvānu" },
  sauna: { src: "/images/sauna.jpg", alt: "Pirts ieeja ar koka apdari" },
  tub: { src: "/images/tub.jpg", alt: "Kubls pagalmā pie koka mājas" },
  banquet: { src: "/images/banquet.jpg", alt: "Svinību zāle ar banketa galdiem" },
  balloons: { src: "/images/balloons.jpg", alt: "Svētku zāle ar baloniem un gaismas zīmi" },
  bike: { src: "/images/bike.jpg", alt: "Ar ziediem rotāts velosipēds teritorijā" },
  lanterns: { src: "/images/lanterns.jpg", alt: "Laternas un šūpuļkrēsls pie verandas loga" },
} satisfies Record<string, Img>;

/* ------------------------------------------------------------------ Ēdienkarte */

export const comboPrice = 32;

export const coldTable = {
  title: "Aukstais galds",
  price: 22,
  items: [
    "Gaļas plate",
    "MINI cūkgaļas karbonādes",
    "Vistas filejas ruletīši",
    "Cūkgaļas kotletītes",
    "Vistas fileja sezamā",
    "Fritēti krabīši",
    "Zivs fileja sarkanajā marinādē",
    "Dārzeņu plate ar zaļumu mērcīti",
    "4 veidu salāti pēc izvēles",
  ],
} as const;

export const warmTable = {
  title: "Siltais galds",
  price: 16,
  included: ["Vārīti kartupeļi ar dillītēm", "Baltā siera mērcīte", "Sautēti kāposti"],
  mains: [
    "Cūkgaļas karbonāde",
    "Vistas filejas karbonāde",
    "Cūkgaļas kotlete",
    "Vistas kotlete",
    "Pildīts vistas veltnītis",
    "Pildīta kotlete",
    "Cepts vistas šķiņķītis",
    "Pildīts cūkgaļas veltnītis",
    "Cepta zivs fileja",
  ],
} as const;

export type PricedItem = { name: string; price: string };

export const salads: PricedItem[] = [
  { name: "Gaļas salāti", price: "11" },
  { name: "Rasols", price: "9.50" },
  { name: "Grauzdiņu salāti", price: "12" },
  { name: "Cēzera salāti", price: "12" },
  { name: "Siļķe kažokā", price: "10" },
  { name: "Mēlīšu salāti", price: "13" },
  { name: "Tunča salāti", price: "12" },
  { name: "Grieķu salāti", price: "12" },
  { name: "Siera salāti", price: "11" },
  { name: "Krabju salāti", price: "11.50" },
  { name: "Pupiņu salāti", price: "11" },
  { name: "Vistas BBQ salāti", price: "12" },
  { name: "Vistas salāti ar pupiņām", price: "12.50" },
  { name: "Liellopu gaļas salāti", price: "14" },
  { name: "Vistas salāti ar ananāsiem", price: "11" },
  { name: "Šampinjonu salāti", price: "11.50" },
];

export const appetizers: PricedItem[] = [
  { name: "Pildīts lavašs", price: "22–25" },
  { name: "Siera plate", price: "22" },
  { name: "Zivju plate", price: "19" },
  { name: "Dārzeņu plate", price: "13" },
  { name: "Zivs sarkanajā marinādē", price: "19" },
  { name: "Gaļas plate", price: "19" },
];

export const dessertPrice = "3.50";

export const desserts = [
  "Zemeņu krēms ar vaniļas mērci",
  "Šokolādes krēms ar ogu mērci",
  "Panna cotta ar zemenēm",
  "Kafijas krēms ar ogu mērci",
  "Auzu pārslu kraukšķis",
  "Abavas sniegs ar ķīseli",
  "Oreo cepumu krēms ar ķīseli",
  "Biezpiena krēms ar ķīseli",
  "Maizes zupa ar putukrējumu",
  "Šokolādes krēms ar vaniļas mērci",
] as const;

/* ------------------------------------------------------------------ Galerija */

export const galleryCategories = ["Visi", "Naktsmītnes", "Svinības", "Omītes virtuve", "Pirts", "Kubuls", "Teritorija"] as const;

export type GalleryCategory = Exclude<(typeof galleryCategories)[number], "Visi">;
export type GalleryItem = Img & { category: GalleryCategory; width: number; height: number };

export const gallery: GalleryItem[] = [
  { ...images.wedding, category: "Svinības", width: 960, height: 1440 },
  { ...images.tub, category: "Kubuls", width: 1440, height: 960 },
  { ...images.table, category: "Svinības", width: 750, height: 1000 },
  { ...images.flowers, category: "Teritorija", width: 1024, height: 683 },
  { ...images.sauna, category: "Pirts", width: 1536, height: 2048 },
  { ...images.banquet, category: "Omītes virtuve", width: 1024, height: 683 },
  { ...images.balloons, category: "Svinības", width: 750, height: 1000 },
  { ...images.bike, category: "Teritorija", width: 1024, height: 683 },
  { ...images.guests, category: "Svinības", width: 2048, height: 1365 },
  { ...images.tubSwing, category: "Kubuls", width: 1024, height: 683 },
  { ...images.lanterns, category: "Teritorija", width: 1024, height: 683 },
  { ...images.balcony, category: "Naktsmītnes", width: 1536, height: 2048 },
  { ...images.decor, category: "Svinības", width: 1024, height: 683 },
  { ...images.veranda, category: "Teritorija", width: 1440, height: 960 },
  { ...images.room, category: "Naktsmītnes", width: 1536, height: 2048 },
  { ...images.pies, category: "Omītes virtuve", width: 1536, height: 2048 },
];
