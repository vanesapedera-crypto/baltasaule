import type { Metadata, Viewport } from "next";
import { Allura, Cormorant_Garamond, Inter } from "next/font/google";
import { MotionProvider } from "@/components/ui/MotionProvider";
import { contact, images, site } from "@/lib/data";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin", "latin-ext"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin", "latin-ext"],
  variable: "--font-inter",
  display: "swap",
});

const allura = Allura({
  subsets: ["latin", "latin-ext"],
  weight: "400",
  variable: "--font-allura",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: `${site.name} — viesu nams, svinības un Omītes virtuve pie jūras`,
    template: `%s | ${site.name}`,
  },
  description: site.seoDescription,
  keywords: [
    "viesu nams pie jūras",
    "svinību zāle",
    "kāzu vieta",
    "jubilejas",
    "kristības",
    "banketi",
    "pirts un kubls",
    site.name,
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: site.locale,
    url: site.url,
    siteName: site.name,
    title: `${site.name} — atpūta pie jūras, svinības un Omītes virtuve`,
    description: site.description,
    images: [{ url: "/images/og.jpg", width: 1200, height: 630, alt: images.hero.alt }],
  },
  twitter: {
    card: "summary_large_image",
    title: site.name,
    description: site.description,
    images: ["/images/og.jpg"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#f4ece1",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LodgingBusiness",
  name: site.name,
  description: site.seoDescription,
  url: site.url,
  image: `${site.url}${images.hero.src}`,
  telephone: contact.phone,
  email: contact.email,
  address: { "@type": "PostalAddress", streetAddress: contact.address, addressCountry: "LV" },
  sameAs: [contact.facebook],
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="lv" className={`${cormorant.variable} ${inter.variable} ${allura.variable}`}>
      <body>
        <a
          href="#saturs"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-caramel focus:px-5 focus:py-3 focus:text-sm focus:text-white"
        >
          Pāriet uz saturu
        </a>
        <MotionProvider>{children}</MotionProvider>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </body>
    </html>
  );
}
