import Image from "next/image";
import { Clock, Facebook, Mail, MapPin, Phone, type LucideIcon } from "lucide-react";
import { contact, images } from "@/lib/data";
import { Reveal } from "@/components/ui/Reveal";
import { Button } from "@/components/ui/Button";

const mapsLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(contact.mapsQuery)}`;
const mapsEmbed = `https://www.google.com/maps?q=${encodeURIComponent(contact.mapsQuery)}&output=embed`;

const links: { icon: LucideIcon; label: string; value: string; href: string; external?: boolean }[] = [
  { icon: Phone, label: "Zvaniet", value: contact.phone, href: contact.phoneHref },
  { icon: Mail, label: "Rakstiet", value: contact.email, href: `mailto:${contact.email}` },
  { icon: MapPin, label: "Atbrauciet", value: contact.address, href: mapsLink, external: true },
];

function IconBadge({ icon: Icon }: { icon: LucideIcon }) {
  return (
    <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-sandwarm text-caramel transition-colors group-hover:bg-caramel group-hover:text-white">
      <Icon aria-hidden className="size-5" />
    </span>
  );
}

export function Contact() {
  return (
    <section id="kontakti" aria-labelledby="contact-title">
      <div className="relative isolate overflow-hidden bg-wood py-28 lg:py-36">
        <Image src={images.flowers.src} alt="" fill sizes="100vw" className="-z-20 object-cover" />
        <div
          aria-hidden
          className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,rgba(42,27,16,0.86)_0%,rgba(42,27,16,0.6)_50%,rgba(42,27,16,0.35)_100%)]"
        />

        <div className="container-x grid items-center gap-14 lg:grid-cols-12">
          <Reveal className="text-white lg:col-span-6">
            <p className="font-script text-5xl leading-none text-amber">Ienāciet ciemos</p>
            <h2 id="contact-title" className="mt-4 text-[clamp(2.8rem,5vw,4.6rem)] font-light leading-[1.02] text-white">
              Sāksim plānot jūsu atpūtu vai svētkus
            </h2>
            <p className="mt-7 max-w-lg text-[1.08rem] leading-[1.85] text-white/80">
              Pastāstiet, ko plānojat — nedēļas nogali divatā, ģimenes svētkus vai kāzas. Mēs atbildēsim un palīdzēsim
              saplānot katru detaļu.
            </p>
          </Reveal>

          <Reveal delay={0.12} className="lg:col-span-5 lg:col-start-8">
            <div className="rounded-3xl bg-paper p-8 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.5)] sm:p-10">
              <ul className="space-y-6">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      {...(link.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      className="group flex items-center gap-4"
                    >
                      <IconBadge icon={link.icon} />
                      <span>
                        <span className="block text-xs uppercase tracking-[0.2em] text-muted">{link.label}</span>
                        <span className="block font-serif text-2xl text-espresso">{link.value}</span>
                      </span>
                      {link.external && <span className="sr-only">(atveras jaunā cilnē)</span>}
                    </a>
                  </li>
                ))}
                <li className="flex items-start gap-4">
                  <IconBadge icon={Clock} />
                  <span className="text-ink/85">
                    {contact.hours.map((h) => (
                      <span key={h.days} className="block">
                        {h.days}: <span className="text-espresso">{h.time}</span>
                      </span>
                    ))}
                    <span className="mt-1 block text-sm text-muted">{contact.hoursNote}</span>
                  </span>
                </li>
              </ul>

              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button href={contact.phoneHref} className="flex-1">
                  Zvanīt tagad
                </Button>
                <Button href={contact.facebook} variant="soft" external className="flex-1">
                  <Facebook aria-hidden className="size-4" />
                  Facebook
                </Button>
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      <div className="relative h-[24rem] bg-sandwarm lg:h-[28rem]">
        <iframe
          title="Baltā Saule Google kartē"
          src={mapsEmbed}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          className="absolute inset-0 size-full border-0 sepia-[.35] saturate-[.85]"
        />
      </div>
    </section>
  );
}
