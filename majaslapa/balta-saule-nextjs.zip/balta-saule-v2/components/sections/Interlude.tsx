"use client";

import { useRef } from "react";
import Image from "next/image";
import { m, useScroll, useTransform } from "framer-motion";
import { images } from "@/lib/data";
import { Reveal } from "@/components/ui/Reveal";

export function Interlude() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  return (
    <section
      ref={ref}
      aria-label="Mūsu vērtības"
      className="relative isolate flex min-h-[75svh] items-center overflow-hidden bg-wood"
    >
      <m.div style={{ y }} className="absolute inset-0 -z-20 scale-[1.2]">
        <Image src={images.guests.src} alt={images.guests.alt} fill sizes="100vw" className="object-cover" />
      </m.div>
      <div aria-hidden className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(42,27,16,0.55),rgba(42,27,16,0.72))]" />

      <div className="container-x py-28 text-center">
        <Reveal className="mx-auto max-w-4xl">
          <blockquote>
            <p className="font-serif text-[clamp(2rem,4.2vw,3.7rem)] font-light italic leading-[1.2] text-white">
              “Mēs ticam, ka visskaistākās atmiņas rodas vietās, kur valda sirsnība, viesmīlība un patiesa rūpe par
              katru viesi.”
            </p>
            <footer className="mt-8 font-script text-4xl text-amber">Baltās Saules ģimene</footer>
          </blockquote>
        </Reveal>
      </div>
    </section>
  );
}
