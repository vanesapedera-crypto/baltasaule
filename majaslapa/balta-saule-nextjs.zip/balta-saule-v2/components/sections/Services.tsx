import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { images } from "@/lib/data";
import { Reveal } from "@/components/ui/Reveal";

const invitations = [
  {
    word: "Svinēt",
    title: "Kāzas, jubilejas, kristības",
    text: "Svinību zāle līdz 40 viesiem un rūpes par katru svētku detaļu.",
    image: images.wedding,
    href: "#svinibas",
  },
  {
    word: "Atpūsties",
    title: "Nedēļas nogale pie jūras",
    text: "Mājīgi numuri, pirts, kubls un priežu smarža dažu soļu no krasta.",
    image: images.tubSwing,
    href: "#naktsmitnes",
  },
  {
    word: "Nogaršot",
    title: "Omītes virtuve",
    text: "Banketi un mājas ēdieni, kas gatavoti ar sirds siltumu.",
    image: images.pies,
    href: "#omites-virtuve",
  },
];

export function Services() {
  return (
    <section aria-labelledby="services-title" className="relative z-10 bg-linen pb-24 lg:pb-32">
      <h2 id="services-title" className="sr-only">
        Ko piedāvājam
      </h2>
      <div className="container-x">
        <ul className="-mt-28 grid gap-6 md:grid-cols-3 lg:-mt-36 lg:gap-8">
          {invitations.map((item, i) => (
            <Reveal as="li" key={item.word} delay={i * 0.12} className={i === 1 ? "md:mt-10" : ""}>
              <a
                href={item.href}
                className="group relative block aspect-[3/4] overflow-hidden rounded-[1.25rem] bg-wood shadow-[0_30px_60px_-28px_rgba(58,40,25,0.65)] transition-transform duration-700 ease-[var(--ease-soft)] hover:-translate-y-2"
              >
                <Image
                  src={item.image.src}
                  alt={item.image.alt}
                  fill
                  sizes="(min-width: 768px) 33vw, 100vw"
                  className="object-cover transition-transform duration-[1.6s] ease-[var(--ease-soft)] group-hover:scale-[1.07]"
                />
                <div
                  aria-hidden
                  className="absolute inset-0 bg-[linear-gradient(180deg,rgba(42,27,16,0)_35%,rgba(42,27,16,0.88)_100%)]"
                />
                <div className="absolute inset-x-0 bottom-0 p-7 text-white sm:p-8">
                  <p className="font-script text-[3.6rem] leading-none text-amber">{item.word}</p>
                  <h3 className="mt-2 text-[1.7rem] leading-tight text-white">{item.title}</h3>
                  <p className="mt-3 max-w-xs leading-relaxed text-white/80">{item.text}</p>
                  <span className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-sand">
                    Uzzināt vairāk
                    <ArrowRight aria-hidden className="size-4 transition-transform duration-500 group-hover:translate-x-1" />
                  </span>
                </div>
              </a>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
