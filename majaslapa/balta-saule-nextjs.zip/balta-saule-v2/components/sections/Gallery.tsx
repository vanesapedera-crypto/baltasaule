"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { AnimatePresence, m } from "framer-motion";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { gallery, galleryCategories } from "@/lib/data";
import { Reveal } from "@/components/ui/Reveal";

type Filter = (typeof galleryCategories)[number];

export function Gallery() {
  const [filter, setFilter] = useState<Filter>("Visi");
  const [index, setIndex] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const triggerRef = useRef<HTMLElement | null>(null);

  const items = useMemo(() => (filter === "Visi" ? gallery : gallery.filter((item) => item.category === filter)), [filter]);
  const current = index === null ? null : items[index];

  const close = useCallback(() => {
    setIndex(null);
    triggerRef.current?.focus();
  }, []);

  const step = useCallback(
    (direction: 1 | -1) => setIndex((i) => (i === null ? i : (i + direction + items.length) % items.length)),
    [items.length],
  );

  useEffect(() => {
    if (index === null) return;

    document.body.style.overflow = "hidden";
    closeRef.current?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
      if (e.key === "Tab" && dialogRef.current) {
        const buttons = dialogRef.current.querySelectorAll<HTMLButtonElement>("button");
        const first = buttons[0];
        const last = buttons[buttons.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [index, close, step]);

  return (
    <section id="galerija" aria-labelledby="gallery-title" className="bg-sandwarm py-28 lg:py-36">
      <div className="container-x">
        <Reveal className="text-center">
          <p className="font-script text-5xl leading-none text-caramel">Mirkļi no Baltās Saules</p>
          <h2 id="gallery-title" className="mt-4 text-[clamp(2.6rem,4.8vw,4.4rem)] font-light leading-[1.05]">
            Galerija
          </h2>
        </Reveal>

        <div role="group" aria-label="Filtrēt galeriju" className="mt-10 flex flex-wrap justify-center gap-2">
          {galleryCategories.map((category) => {
            const isActive = category === filter;
            return (
              <button
                key={category}
                type="button"
                aria-pressed={isActive}
                onClick={() => setFilter(category)}
                className={`min-h-11 rounded-full px-5 text-sm font-medium transition-all duration-500 ${
                  isActive ? "bg-caramel text-white shadow-[0_10px_24px_-12px_rgba(126,84,52,0.9)]" : "bg-linen text-ink hover:bg-paper"
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        <ul className="mt-14 columns-2 gap-3 sm:gap-4 lg:columns-3 [&>li]:mb-3 sm:[&>li]:mb-4">
          <AnimatePresence mode="popLayout">
            {items.map((item, i) => (
              <m.li
                key={item.src}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.7 }}
                className="break-inside-avoid"
              >
                <button
                  type="button"
                  onClick={(e) => {
                    triggerRef.current = e.currentTarget;
                    setIndex(i);
                  }}
                  aria-label={`Atvērt attēlu: ${item.alt}`}
                  className="group relative block w-full overflow-hidden rounded-2xl bg-sand-soft"
                >
                  <Image
                    src={item.src}
                    alt={item.alt}
                    width={item.width}
                    height={item.height}
                    sizes="(min-width: 1024px) 33vw, 50vw"
                    className="h-auto w-full transition-transform duration-[1.6s] ease-[var(--ease-soft)] group-hover:scale-[1.05]"
                  />
                  <span className="absolute inset-0 flex items-end bg-gradient-to-t from-wood/70 via-transparent to-transparent p-5 text-left opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100">
                    <span>
                      <span className="block text-[0.7rem] uppercase tracking-[0.22em] text-amber">{item.category}</span>
                      <span className="mt-1 block font-serif text-xl leading-snug text-white">{item.alt}</span>
                    </span>
                  </span>
                </button>
              </m.li>
            ))}
          </AnimatePresence>
        </ul>
      </div>

      <AnimatePresence>
        {current && index !== null && (
          <m.div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-label={`Attēls ${index + 1} no ${items.length}: ${current.alt}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={close}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-wood/95 p-4 backdrop-blur-md sm:p-10"
          >
            <m.figure
              key={current.src}
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              onClick={(e) => e.stopPropagation()}
              className="flex w-full max-w-6xl flex-col items-center"
            >
              <div className="relative h-[78vh] w-full">
                <Image src={current.src} alt={current.alt} fill sizes="100vw" className="object-contain" />
              </div>
              <figcaption className="mt-5 text-center text-sand-soft">
                <span className="font-serif text-xl">{current.alt}</span>
                <span className="ml-3 text-sm text-sand-soft/60">
                  {index + 1} / {items.length}
                </span>
              </figcaption>
            </m.figure>

            <button
              ref={closeRef}
              type="button"
              onClick={close}
              aria-label="Aizvērt"
              className="absolute right-4 top-4 inline-flex size-12 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-wood sm:right-8 sm:top-8"
            >
              <X aria-hidden className="size-6" />
            </button>
            {items.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    step(-1);
                  }}
                  aria-label="Iepriekšējais attēls"
                  className="absolute left-3 top-1/2 inline-flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-wood sm:left-8"
                >
                  <ChevronLeft aria-hidden className="size-6" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    step(1);
                  }}
                  aria-label="Nākamais attēls"
                  className="absolute right-3 top-1/2 inline-flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-wood sm:right-8"
                >
                  <ChevronRight aria-hidden className="size-6" />
                </button>
              </>
            )}
          </m.div>
        )}
      </AnimatePresence>
    </section>
  );
}
