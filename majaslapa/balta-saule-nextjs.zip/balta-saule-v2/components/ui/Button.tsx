import { ArrowRight } from "lucide-react";

type Variant = "primary" | "ghost" | "soft";

const styles: Record<Variant, string> = {
  primary:
    "bg-caramel text-white shadow-[0_14px_30px_-14px_rgba(126,84,52,0.8)] hover:bg-caramel-dark hover:shadow-[0_18px_40px_-14px_rgba(126,84,52,0.9)]",
  ghost: "border border-white/60 text-white hover:bg-white hover:text-wood",
  soft: "bg-sandwarm text-wood hover:bg-sand",
};

type Props = {
  href: string;
  children: React.ReactNode;
  variant?: Variant;
  arrow?: boolean;
  external?: boolean;
  className?: string;
};

export function Button({ href, children, variant = "primary", arrow = false, external = false, className = "" }: Props) {
  return (
    <a
      href={href}
      {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      className={`group inline-flex min-h-14 items-center justify-center gap-3 rounded-full px-8 text-[0.95rem] font-medium tracking-wide transition-all duration-500 ease-[var(--ease-soft)] hover:-translate-y-0.5 ${styles[variant]} ${className}`}
    >
      {children}
      {arrow && <ArrowRight aria-hidden className="size-4 transition-transform duration-500 group-hover:translate-x-1" />}
      {external && <span className="sr-only">(atveras jaunā cilnē)</span>}
    </a>
  );
}
