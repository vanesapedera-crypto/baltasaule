"use client";

import { m } from "framer-motion";

const ease = [0.16, 1, 0.3, 1] as const;

type Props = {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "li";
};

/** Maigs fade-in + slide-up, kad elements parādās skatā. */
export function Reveal({ children, className, delay = 0, as = "div" }: Props) {
  const motionProps = {
    className,
    initial: { opacity: 0, y: 24 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "0px 0px -10% 0px" },
    transition: { duration: 1.1, ease, delay },
  } as const;

  return as === "li" ? <m.li {...motionProps}>{children}</m.li> : <m.div {...motionProps}>{children}</m.div>;
}
