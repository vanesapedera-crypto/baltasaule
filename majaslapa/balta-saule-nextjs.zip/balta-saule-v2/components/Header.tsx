"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, m } from "framer-motion";
import { Menu, Phone, X } from "lucide-react";
import { contact, navItems, site } from "@/lib/data";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>(navItems[0].href);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const sections = navItems
      .map((item) => document.querySelector<HTMLElement>(item.href))
      .filter((el): el is HTMLElement => el !== null);

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActive(`#${entry.target.id}`);
        }
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );

    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const solid = scrolled || open;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-[var(--ease-soft)] ${
        solid
          ? "bg-linen/95 py-3 shadow-[0_10px_30px_-20px_rgba(58,40,25,0.45)] backdrop-blur-xl"
          : "bg-transparent py-6 [text-shadow:0_1px_16px_rgba(33,23,16,0.35)]"
      }`}
    >
      <div className="container-x flex items-center justify-between gap-6">
        <a
          href="#sakums"
          aria-label={`${site.name} — uz sākumu`}
          className={`relative z-10 font-script text-[2.2rem] leading-none transition-colors duration-500 ${
            solid ? "text-espresso" : "text-white"
          }`}
        >
          {site.name}
        </a>

        <nav aria-label="Galvenā navigācija" className="hidden xl:block">
          <ul className="flex items-center gap-1">
            {navItems.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  aria-current={active === item.href ? "location" : undefined}
                  className={`relative rounded-full px-3.5 py-2 text-[0.88rem] font-medium transition-colors duration-300 after:absolute after:inset-x-3.5 after:bottom-0.5 after:h-px after:origin-left after:bg-current after:transition-transform after:duration-500 hover:after:scale-x-100 ${
                    active === item.href ? "after:scale-x-100" : "after:scale-x-0"
                  } ${solid ? "text-espresso hover:text-caramel" : "text-white/90 hover:text-white"}`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={contact.phoneHref}
            className={`hidden min-h-12 items-center gap-2 rounded-full px-6 text-sm font-medium transition-all duration-500 hover:-translate-y-0.5 sm:inline-flex ${
              solid ? "bg-caramel text-white hover:bg-caramel-dark" : "bg-white text-wood hover:bg-caramel hover:text-white"
            }`}
          >
            <Phone aria-hidden className="size-4" />
            Zvanīt
          </a>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls="mobilais-menu"
            aria-label={open ? "Aizvērt izvēlni" : "Atvērt izvēlni"}
            className={`relative z-10 inline-flex size-12 items-center justify-center rounded-full transition-colors xl:hidden ${
              solid ? "text-espresso hover:bg-sandwarm" : "text-white hover:bg-white/10"
            }`}
          >
            {open ? <X aria-hidden className="size-6" /> : <Menu aria-hidden className="size-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <m.div
            id="mobilais-menu"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-x-0 top-0 h-dvh overflow-y-auto bg-linen px-6 pb-10 pt-28 xl:hidden"
          >
            <nav aria-label="Mobilā navigācija">
              <ul className="flex flex-col">
                {navItems.map((item) => (
                  <li key={item.href}>
                    <a
                      href={item.href}
                      onClick={() => setOpen(false)}
                      className="block py-3 font-serif text-3xl text-espresso transition-colors hover:text-caramel"
                    >
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
            <a
              href={contact.phoneHref}
              className="mt-10 flex min-h-14 w-full items-center justify-center gap-2 rounded-full bg-caramel px-7 text-base font-medium text-white"
            >
              <Phone aria-hidden className="size-4" />
              {contact.phone}
            </a>
          </m.div>
        )}
      </AnimatePresence>
    </header>
  );
}
