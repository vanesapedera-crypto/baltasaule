# Baltā Saule — mājaslapa

Next.js 15 · React 19 · Tailwind CSS 4 · Framer Motion · Lucide React

## Palaišana

```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start   # produkcijas režīms
```

Ieteicamā publicēšana: **Vercel** (importējiet repozitoriju — konfigurācija nav vajadzīga).

## Pirms publicēšanas — obligāti

1. **Kontakti** — `lib/data.ts` → `contact`: telefons, e-pasts, adrese, Facebook saite, darba laiks, kartes adrese (`mapsQuery`). Pašlaik tur ir pagaidu vērtības (atzīmētas ar `TODO`).
2. **Domēns** — `lib/data.ts` → `site.url` (izmanto SEO, sitemap un Open Graph).
3. **Fotogrāfijas** — `public/images/` ir Baltās Saules īstās fotogrāfijas. Kurš foto kur tiek rādīts, nosaka `lib/data.ts` → `images` un `gallery`. Lai nomainītu foto, ievietojiet failu mapē un nomainiet `src`. Kadrējumu var pielāgot ar `pos` (piem. `pos: "50% 80%"`). Galerijai norādiet arī attēla izmērus (`w`, `h`), lai masonry saglabātu dabiskās proporcijas.
   - Vēlams: augstākas izšķirtspējas oriģināli hero (`hero.jpg`, `flowers.jpg`, `banquet.jpg` — šobrīd ~1024 px plati).
   - Ēdienkartē salātiem, uzkodām un desertiem pagaidām nav foto — tie rādīti tipogrāfiski. Kad būs ēdienu foto, ēdienkarte ir veidota kā drukāta ēdienkarte bez attēliem (`components/sections/Kitchen.tsx`).
   - Galerijā var pievienot kategorijas "Ēdieni" un "Jūra" (`galleryCategories`), kad būs attiecīgie foto.

## Struktūra

```
app/
  layout.tsx        fonti (Cormorant Garamond, Inter, Allura), SEO metadati, JSON-LD
  page.tsx          sadaļu kompozīcija
  globals.css       krāsu palete un dizaina tokeni (Tailwind @theme)
  sitemap.ts, robots.ts, icon.svg
components/
  Header.tsx        caurspīdīgs virs hero → balts pēc ritināšanas, mobilā izvēlne
  Footer.tsx        vieglā kājene ar lielu vārdzīmi
  sections/         Hero, Services (trīs ielūgumi: svinēt, atpūsties, nogaršot), About (foto kolāža), Celebrations, Interlude (citāts uz foto), Stays (rīts–nakts), Kitchen (papīra ēdienkarte), Gallery, Contact
  ui/               Button, Reveal, Logo, MotionProvider
lib/data.ts         VISS saturs: kontakti, navigācija, ēdienkarte, cenas, galerija
```

Cenas un ēdienkarti maina tikai `lib/data.ts` — komponentos nekas nav jāaiztiek.

## Veiktspēja un pieejamība

- `next/image` ar AVIF/WebP, `sizes`, lazy loading; hero attēls ar `priority`
- `next/font` (bez ārējiem pieprasījumiem, `display: swap`)
- Framer Motion caur `LazyMotion` (mazāks JS), ievēro `prefers-reduced-motion`
- Semantisks HTML, `aria` etiķetes, "Pāriet uz saturu" saite, fokusa stāvokļi, lightbox ar tastatūras vadību (Esc, ←, →) un fokusa slazdu
- Teksta kontrasts atbilst WCAG AA
