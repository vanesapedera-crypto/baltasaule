import { Facebook } from "lucide-react";
import { contact, navItems } from "@/lib/data";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-wood text-sand-soft">
      <div className="container-x grid gap-12 py-20 md:grid-cols-2 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <p className="font-script text-6xl leading-none text-amber">Baltā Saule</p>
          <p className="mt-6 max-w-sm leading-relaxed text-sand-soft/75">
            Ģimenes viesu nams dažu soļu attālumā no jūras — mājīgas naktsmītnes, svinības līdz 40 viesiem un Omītes
            virtuve ar sirds siltumu.
          </p>
          <a
            href={contact.facebook}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Baltā Saule Facebook lapa (atveras jaunā cilnē)"
            className="mt-8 inline-flex size-12 items-center justify-center rounded-full bg-white/10 text-sand transition-colors hover:bg-amber hover:text-wood"
          >
            <Facebook aria-hidden className="size-5" />
          </a>
        </div>

        <nav aria-label="Ātrās saites" className="lg:col-span-3">
          <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.24em] !text-amber">Saites</h2>
          <ul className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 lg:grid-cols-1">
            {navItems.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="text-sand-soft/80 transition-colors hover:text-white">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-4">
          <h2 className="font-sans text-xs font-semibold uppercase tracking-[0.24em] !text-amber">Kontakti</h2>
          <address className="mt-6 space-y-3 not-italic text-sand-soft/80">
            <a href={contact.phoneHref} className="block transition-colors hover:text-white">
              {contact.phone}
            </a>
            <a href={`mailto:${contact.email}`} className="block transition-colors hover:text-white">
              {contact.email}
            </a>
            <p>{contact.address}</p>
          </address>
        </div>
      </div>
      <div className="bg-black/15">
        <div className="container-x flex flex-col items-center justify-between gap-2 py-6 text-sm text-sand-soft/60 sm:flex-row">
          <p>© {year} Baltā Saule. Visas tiesības aizsargātas.</p>
          <p className="font-script text-2xl text-amber/80">ar sirsnību pie jūras</p>
        </div>
      </div>
    </footer>
  );
}
