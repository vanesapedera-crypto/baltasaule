import Image from "next/image";
import { Clock, Facebook, Mail, MapPin, Phone } from "lucide-react";
import { contact, images } from "@/lib/data";
import { Reveal } from "../ui/Reveal";
import { Button } from "../ui/Button";

const mapsLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(contact.mapsQuery)}`;
const mapsEmbed = `https://www.google.com/maps?q=${encodeURIComponent(contact.mapsQuery)}&output=embed`;

export function Contact() {
  return (
    <section id="kontakti" aria-labelledby="contact-title">
      {/* Ielūgums uz silta foto fona ar kontaktu kartiņu */}
      <div className="relative isolate overflow-hidden bg-wood py-28 lg:py-36">
        <Image src={images.flowers.src} alt="" fill sizes="100vw" className="-z-20 object-cover" />
        <div aria-hidden className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,rgba(42,27,16,0.85)_0%,rgba(42,27,16,0.6)_50%,rgba(42,27,16,0.35)_100%)]" />

        <div className="container-x grid items-center gap-14 lg:grid-cols-12">
          <Reveal className="text-white lg:col-span-6">
            <p className="font-script text-5xl leading-none text-amber">Ienāciet ciemos</p>
            <h2 id="contact-title" className="mt-4 text-[clamp(2.8rem,5vw,4.6rem)] font-light leading-[1.02] !text-white">
              Sāksim plānot jūsu atpūtu vai svētkus
            </h2>
            <p className="mt-7 max-w-lg text-[1.08rem] leading-[1.85] text-white/80">
              Pastāstiet, ko sapņojat — nedēļas nogali divatā, ģimenes svētkus vai kāzas. Mēs atbildēsim, parādīsim
              visu uz vietas un palīdzēsim saplānot katru detaļu.
            </p>
          </Reveal>

          <Reveal delay={0.12} className="lg:col-span-5 lg:col-start-8">
            <div className="rounded-[1.5rem] bg-[#fffaf2] p-8 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.5)] sm:p-10">
              <ul className="space-y-6">
                <li>
                  <a href={contact.phoneHref} className="group flex items-center gap-4">
                    <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-sandwarm text-caramel transition-colors group-hover:bg-caramel group-hover:text-white">
                      <Phone aria-hidden className="size-5" />
                    </span>
                    <span>
                      <span className="block text-xs uppercase tracking-[0.2em] text-muted">Zvaniet</span>
                      <span className="block font-serif text-2xl text-espresso">{contact.phone}</span>
                    </span>
                  </a>
                </li>
                <li>
                  <a href={`mailto:${contact.email}`} className="group flex items-center gap-4">
                    <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-sandwarm text-caramel transition-colors group-hover:bg-caramel group-hover:text-white">
                      <Mail aria-hidden className="size-5" />
                    </span>
                    <span>
                      <span className="block text-xs uppercase tracking-[0.2em] text-muted">Rakstiet</span>
                      <span className="block font-serif text-2xl text-espresso">{contact.email}</span>
                    </span>
                  </a>
                </li>
                <li>
                  <a href={mapsLink} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4">
                    <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-sandwarm text-caramel transition-colors group-hover:bg-caramel group-hover:text-white">
                      <MapPin aria-hidden className="size-5" />
                    </span>
                    <span>
                      <span className="block text-xs uppercase tracking-[0.2em] text-muted">Atbrauciet</span>
                      <span className="block font-serif text-2xl text-espresso">{contact.address}</span>
                    </span>
                    <span className="sr-only">(atveras Google Maps jaunā cilnē)</span>
                  </a>
                </li>
                <li className="flex items-start gap-4">
                  <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-full bg-sandwarm text-caramel">
                    <Clock aria-hidden className="size-5" />
                  </span>
                  <span className="text-ink/85">
                    {contact.hours.map((h) => (
                      <span key={h.days} className="block">
                        {h.days}: <span className="text-espresso">{h.time}</span>
                      </span>
                    ))}
                    <span className="mt-1 block text-sm text-muted">{contact.hoursNote}</span>
                  </span>
                </li>
              </ul>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button href={contact.phoneHref} className="flex-1">
                  Zvanīt tagad
                </Button>
                <a
                  href={contact.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-14 flex-1 items-center justify-center gap-2 rounded-full bg-sandwarm px-6 text-[0.95rem] font-medium text-wood transition-colors hover:bg-sand"
                >
                  <Facebook aria-hidden className="size-4" />
                  Facebook
                  <span className="sr-only">(atveras jaunā cilnē)</span>
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      {/* Karte */}
      <div className="relative h-[24rem] bg-sandwarm lg:h-[28rem]">
        <iframe
          title="Baltā Saule Google kartē"
          src={mapsEmbed}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          className="absolute inset-0 size-full border-0 sepia-[.35] saturate-[.85]"
        />
      </div>
    </section>
  );
}
