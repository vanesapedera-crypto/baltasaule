"use client";

import { useRef } from "react";
import Image from "next/image";
import { m, useScroll, useTransform } from "framer-motion";
import { images, site } from "@/lib/data";
import { Button } from "../ui/Button";

const ease = [0.16, 1, 0.3, 1] as const;

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);

  return (
    <section
      id="sakums"
      ref={ref}
      aria-labelledby="hero-title"
      className="relative isolate flex min-h-[100svh] items-center overflow-hidden bg-wood text-white"
    >
      <m.div style={{ y }} className="absolute inset-0 -z-20 scale-110 will-change-transform">
        <Image src={images.hero.src} alt={images.hero.alt} fill priority fetchPriority="high" sizes="100vw" quality={88} className="object-cover" />
      </m.div>
      {/* Silta vakara saules gaisma: medus tonis + tumšāks pa kreisi tekstam */}
      <div aria-hidden className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,rgba(42,27,16,0.78)_0%,rgba(58,40,25,0.45)_45%,rgba(150,103,63,0.15)_100%)]" />
      <div aria-hidden className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_85%_15%,rgba(255,196,120,0.35),transparent_55%)] mix-blend-soft-light" />

      <div className="container-x w-full pb-44 pt-36">
        <div className="max-w-2xl">
          <m.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 0.2 }}
            className="font-script text-[clamp(2.4rem,4.5vw,3.6rem)] leading-none text-amber"
          >
            Laipni lūdzam
          </m.p>
          <m.h1
            id="hero-title"
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.4, ease, delay: 0.35 }}
            className="mt-3 text-[clamp(4rem,10vw,8.5rem)] font-light leading-[0.95] !text-white"
          >
            Baltajā Saulē
          </m.h1>
          <m.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 0.6 }}
            className="mt-8 text-[0.82rem] font-medium uppercase tracking-[0.28em] text-sand"
          >
            {site.tagline}
          </m.p>
          <m.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 0.72 }}
            className="mt-6 max-w-lg font-serif text-[1.55rem] italic leading-snug text-white/90"
          >
            {site.description}
          </m.p>
          <m.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease, delay: 0.85 }}
            className="mt-10 flex flex-col gap-4 sm:flex-row"
          >
            <Button href="#piedavajums" arrow>
              Apskatīt piedāvājumu
            </Button>
            <Button href="#kontakti" variant="ghost">
              Sazināties
            </Button>
          </m.div>
        </div>
      </div>
    </section>
  );
}
