"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { AnimatePresence, m } from "framer-motion";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { gallery, galleryCategories } from "@/lib/data";
import { Reveal } from "../ui/Reveal";

type Filter = (typeof galleryCategories)[number];


export function Gallery() {
  const [filter, setFilter] = useState<Filter>("Visi");
  const [index, setIndex] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const lastTrigger = useRef<HTMLElement | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  const items = useMemo(
    () => (filter === "Visi" ? gallery : gallery.filter((g) => g.category === filter)),
    [filter],
  );

  const open = (i: number, el: HTMLElement) => {
    lastTrigger.current = el;
    setIndex(i);
  };
  const close = useCallback(() => {
    setIndex(null);
    lastTrigger.current?.focus();
  }, []);
  const step = useCallback(
    (dir: 1 | -1) => setIndex((i) => (i === null ? i : (i + dir + items.length) % items.length)),
    [items.length],
  );

  useEffect(() => {
    if (index === null) return;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
      if (e.key === "Tab" && dialogRef.current) {
        const f = dialogRef.current.querySelectorAll<HTMLElement>("button");
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [index, close, step]);

  const current = index !== null ? items[index] : null;

  return (
    <section id="galerija" aria-labelledby="gallery-title" className="bg-sandwarm py-28 lg:py-36">
      <div className="container-x">
        <Reveal className="text-center">
          <p className="font-script text-5xl leading-none text-caramel">Mirkļi no Baltās Saules</p>
          <h2 id="gallery-title" className="mt-4 text-[clamp(2.6rem,4.8vw,4.4rem)] font-light leading-[1.05]">
            Galerija
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <div role="group" aria-label="Filtrēt galeriju pēc kategorijas" className="mt-10 flex flex-wrap justify-center gap-2">
            {galleryCategories.map((c) => {
              const isActive = c === filter;
              return (
                <button
                  key={c}
                  type="button"
                  aria-pressed={isActive}
                  onClick={() => setFilter(c)}
                  className={`min-h-11 rounded-full px-5 text-sm font-medium transition-all duration-500 ${
                    isActive ? "bg-caramel text-white shadow-[0_10px_24px_-12px_rgba(126,84,52,0.9)]" : "bg-linen text-ink hover:bg-white"
                  }`}
                >
                  {c}
                </button>
              );
            })}
          </div>
        </Reveal>
      </div>

      <div className="container-x mt-14">
        <ul className="columns-2 gap-3 sm:gap-4 lg:columns-3 [&>li]:mb-3 sm:[&>li]:mb-4">
          <AnimatePresence mode="popLayout">
            {items.map((item, i) => (
              <m.li
                key={item.src}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                className="break-inside-avoid"
              >
                <button
                  type="button"
                  onClick={(e) => open(i, e.currentTarget)}
                  aria-label={`Atvērt attēlu: ${item.alt}`}
                  className="group relative block w-full overflow-hidden rounded-[1rem] bg-sand-soft"
                >
                  <Image
                    src={item.src}
                    alt={item.alt}
                    width={item.w}
                    height={item.h}
                    sizes="(min-width: 1024px) 33vw, 50vw"
                    className="h-auto w-full transition-transform duration-[1.8s] ease-[var(--ease-soft)] group-hover:scale-[1.05]"
                  />
                  <span className="absolute inset-0 flex items-end bg-gradient-to-t from-espresso/60 via-espresso/0 to-transparent p-5 text-left opacity-0 transition-opacity duration-700 group-hover:opacity-100 group-focus-visible:opacity-100 sm:p-7">
                    <span>
                      <span className="block text-[0.68rem] uppercase tracking-[0.26em] text-white/80">{item.category}</span>
                      <span className="mt-1.5 block font-serif text-xl leading-snug text-white sm:text-2xl">{item.alt}</span>
                    </span>
                  </span>
                </button>
              </m.li>
            ))}
          </AnimatePresence>
        </ul>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {current && index !== null && (
          <m.div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-label={`Attēls ${index + 1} no ${items.length}: ${current.alt}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-wood/95 p-4 backdrop-blur-md sm:p-10"
            onClick={close}
          >
            <m.figure
              key={current.src}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="relative flex max-h-full w-full max-w-6xl flex-col items-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative h-[78vh] w-full">
                <Image src={current.src} alt={current.alt} fill sizes="100vw" className="object-contain" priority />
              </div>
              <figcaption className="mt-5 text-center text-sand-soft">
                <span className="text-xs uppercase tracking-[0.2em] text-sand">{current.category}</span>
                <span className="mx-3 text-sand/50">•</span>
                <span className="font-serif text-xl">{current.alt}</span>
                <span className="ml-3 text-sm text-sand-soft/60">
                  {index + 1} / {items.length}
                </span>
              </figcaption>
            </m.figure>

            <button
              ref={closeRef}
              type="button"
              onClick={close}
              aria-label="Aizvērt"
              className="absolute right-4 top-4 inline-flex size-12 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-ink sm:right-8 sm:top-8"
            >
              <X className="size-6" aria-hidden />
            </button>
            {items.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    step(-1);
                  }}
                  aria-label="Iepriekšējais attēls"
                  className="absolute left-3 top-1/2 inline-flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-ink sm:left-8"
                >
                  <ChevronLeft className="size-6" aria-hidden />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    step(1);
                  }}
                  aria-label="Nākamais attēls"
                  className="absolute right-3 top-1/2 inline-flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white hover:text-ink sm:right-8"
                >
                  <ChevronRight className="size-6" aria-hidden />
                </button>
              </>
            )}
          </m.div>
        )}
      </AnimatePresence>
    </section>
  );
}
