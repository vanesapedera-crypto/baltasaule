import Image from "next/image";
import { images, type Img } from "@/lib/data";
import { Reveal } from "../ui/Reveal";
import { Button } from "../ui/Button";

const events = ["Kāzas", "Jubilejas", "Kristības", "Dzimšanas dienas", "Uzņēmumu pasākumi"];

const care = [
  { title: "Svinību zāle", text: "Silta koka zāle līdz 40 viesiem, klāta tieši jūsu svētkiem." },
  { title: "Omītes virtuve", text: "Banketi, aukstais un siltais galds, deserti — viss uz vietas." },
  { title: "Smaidu darbnīca", text: "Scenārijs, vadīšana un bērnu aktivitātes — bez raizēm." },
  { title: "Svētku dekori", text: "Ziedi, gaismas un noformējums, ko rada mūsu meita." },
];

function Tile({ img, className, sizes }: { img: Img; className: string; sizes: string }) {
  return (
    <div className={`group relative overflow-hidden rounded-[1rem] ${className}`}>
      <Image
        src={img.src}
        alt={img.alt}
        fill
        sizes={sizes}
        className="object-cover transition-transform duration-[1.6s] ease-[var(--ease-soft)] group-hover:scale-[1.06]"
      />
    </div>
  );
}

export function Celebrations() {
  return (
    <section id="svinibas" aria-labelledby="celebrations-title" className="relative overflow-hidden bg-wood py-28 text-white lg:py-36">
      <div aria-hidden className="pointer-events-none absolute -left-40 top-0 size-[40rem] rounded-full bg-[radial-gradient(circle,rgba(217,168,113,0.18),transparent_65%)]" />
      <div className="container-x relative grid items-center gap-16 lg:grid-cols-12">
        <Reveal className="lg:col-span-5">
          <p className="font-script text-5xl leading-none text-amber">Jūsu lielā diena</p>
          <h2 id="celebrations-title" className="mt-4 text-[clamp(2.8rem,5vw,4.6rem)] font-light leading-[1.02] !text-white">
            Svinības, kuras atcerēsieties vienmēr
          </h2>
          <p className="mt-7 text-[1.08rem] leading-[1.85] text-white/75">
            Garš, klāts galds koka zālē, smiekli, dejas un vakars, kas beidzas pie jūras. Jūs baudāt brīdi — par pārējo
            parūpēsimies mēs.
          </p>
          <p className="mt-6 font-serif text-xl italic text-sand">{events.join(" · ")}</p>
          <div className="mt-10">
            <Button href="#kontakti" arrow>
              Plānot svinības
            </Button>
          </div>
        </Reveal>

        <Reveal delay={0.12} className="lg:col-span-7">
          <div className="grid h-[34rem] grid-cols-6 grid-rows-6 gap-3 sm:h-[40rem] sm:gap-4">
            <Tile img={images.hall} className="col-span-3 row-span-6" sizes="(min-width: 1024px) 30vw, 50vw" />
            <Tile img={images.table} className="col-span-3 row-span-3" sizes="(min-width: 1024px) 28vw, 50vw" />
            <Tile img={{ src: "/images/decor.jpg", alt: "Svētku dekori ar lampiņām un sausziediem" }} className="col-span-3 row-span-3" sizes="(min-width: 1024px) 28vw, 50vw" />
          </div>
        </Reveal>
      </div>

      <div className="container-x relative mt-20 lg:mt-28">
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {care.map((c, i) => (
            <Reveal as="li" key={c.title} delay={i * 0.08}>
              <div className="h-full rounded-[1rem] bg-white/[0.06] p-7 transition-colors duration-500 hover:bg-white/[0.1]">
                <p className="font-serif text-lg italic text-amber">0{i + 1}</p>
                <h3 className="mt-2 text-[1.6rem] !text-white">{c.title}</h3>
                <p className="mt-2 leading-relaxed text-white/70">{c.text}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
