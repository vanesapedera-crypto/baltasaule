import Image from "next/image";
import { appetizers, coldTable, comboPrice, dessertPrice, desserts, images, salads, warmTable } from "@/lib/data";
import { Reveal } from "../ui/Reveal";
import { Button } from "../ui/Button";

/** Latviešu formāts: 9.50 → 9,50 */
const eur = (v: string | number) => `${String(v).replace(".", ",")} €`;

function Heading({ id, title, price, unit }: { id: string; title: string; price?: string | number; unit?: string }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b border-sand/60 pb-3">
      <h3 id={id} className="text-[2rem] font-normal">
        {title}
      </h3>
      {price !== undefined && (
        <p className="font-serif text-xl italic text-caramel">
          {eur(price)} / {unit}
        </p>
      )}
    </div>
  );
}

function Dish({ name, price }: { name: string; price?: string }) {
  return (
    <li className="flex items-baseline gap-3 py-1.5">
      <span className="text-[1.02rem] text-ink">{name}</span>
      {price && (
        <>
          <span aria-hidden className="dotted-leader" />
          <span className="shrink-0 font-serif text-lg text-espresso">{eur(price)}</span>
        </>
      )}
    </li>
  );
}

export function Kitchen() {
  return (
    <section id="omites-virtuve" aria-labelledby="kitchen-title" className="overflow-hidden bg-linen py-28 lg:py-36">
      <div className="container-x">
        {/* Ievads ar divām pārklājošām fotogrāfijām */}
        <div className="grid items-center gap-16 lg:grid-cols-12">
          <Reveal className="relative h-[30rem] sm:h-[36rem] lg:col-span-6">
            <div className="group absolute left-0 top-0 h-[85%] w-[70%] overflow-hidden rounded-[1.25rem] shadow-[0_30px_60px_-28px_rgba(58,40,25,0.6)]">
              <Image src={images.pies.src} alt={images.pies.alt} fill sizes="(min-width: 1024px) 34vw, 70vw" className="object-cover transition-transform duration-[1.6s] group-hover:scale-[1.06]" />
            </div>
            <div className="group absolute bottom-0 right-0 h-[48%] w-[52%] overflow-hidden rounded-[1.25rem] border-[6px] border-linen shadow-[0_30px_60px_-28px_rgba(58,40,25,0.6)]">
              <Image src={images.banquet.src} alt={images.banquet.alt} fill sizes="(min-width: 1024px) 26vw, 52vw" className="object-cover transition-transform duration-[1.6s] group-hover:scale-[1.06]" />
            </div>
          </Reveal>

          <Reveal delay={0.12} className="lg:col-span-6 lg:pl-8">
            <p className="font-script text-5xl leading-none text-caramel">No Omītes virtuves</p>
            <h2 id="kitchen-title" className="mt-4 text-[clamp(2.6rem,4.8vw,4.4rem)] font-light leading-[1.05]">
              Ēdiens, kas garšo pēc mājām
            </h2>
            <p className="mt-7 text-[1.05rem] leading-[1.85] text-ink/85">
              Saimniece Alda jau daudzus gadus gatavo ēdienus ar sirds siltumu un rūpību. Katrs ēdiens top no
              kvalitatīviem produktiem, izmantojot pārbaudītas receptes un mājas virtuves tradīcijas — lai jūsu svētku
              galds būtu bagātīgs un viesi paēduši.
            </p>
            <p className="mt-8 font-script text-4xl text-espresso">— Alda</p>
          </Reveal>
        </div>

        {/* Ēdienkarte kā īsta papīra ēdienkarte uz galda */}
        <Reveal className="mt-24 lg:mt-32">
          <div className="relative mx-auto max-w-6xl rounded-[1.5rem] bg-[#fffaf2] px-6 py-14 shadow-[0_40px_80px_-40px_rgba(58,40,25,0.45)] sm:px-12 lg:px-20 lg:py-20">
            <div className="text-center">
              <p className="font-script text-6xl leading-none text-caramel">Ēdienkarte</p>
              <p className="mt-4 font-serif text-xl italic text-ink/70">
                Aukstais un siltais galds kopā — <span className="not-italic text-caramel">{comboPrice} € / persona</span>
              </p>
            </div>

            <div className="mt-14 grid gap-14 lg:grid-cols-2 lg:gap-20">
              <div className="space-y-14">
                <article id="aukstais-galds" aria-labelledby="cold-title" className="scroll-mt-28">
                  <Heading id="cold-title" title={coldTable.title} price={coldTable.price} unit="persona" />
                  <ul className="mt-4">
                    {coldTable.items.map((d) => (
                      <Dish key={d} name={d} />
                    ))}
                  </ul>
                </article>

                <article id="siltais-galds" aria-labelledby="warm-title" className="scroll-mt-28">
                  <Heading id="warm-title" title={warmTable.title} price={warmTable.price} unit="persona" />
                  <p className="mt-4 font-serif text-lg italic text-ink/75">{warmTable.included.join(", ")}</p>
                  <p className="mt-4 text-xs font-medium uppercase tracking-[0.22em] text-caramel">Izvēle no trim ēdieniem</p>
                  <ul className="mt-2">
                    {warmTable.mains.map((d) => (
                      <Dish key={d} name={d} />
                    ))}
                  </ul>
                </article>
              </div>

              <div className="space-y-14">
                <article id="salati" aria-labelledby="salads-title" className="scroll-mt-28">
                  <Heading id="salads-title" title="Salāti" />
                  <p className="mt-2 text-xs uppercase tracking-[0.22em] text-muted">Cena par kilogramu</p>
                  <ul className="mt-3">
                    {salads.map((s) => (
                      <Dish key={s.name} name={s.name} price={s.price} />
                    ))}
                  </ul>
                </article>

                <article id="uzkodas" aria-labelledby="app-title" className="scroll-mt-28">
                  <Heading id="app-title" title="Uzkodas" />
                  <p className="mt-2 text-xs uppercase tracking-[0.22em] text-muted">Cena par kilogramu</p>
                  <ul className="mt-3">
                    {appetizers.map((a) => (
                      <Dish key={a.name} name={a.name} price={a.price} />
                    ))}
                  </ul>
                </article>
              </div>
            </div>

            <article id="deserti" aria-labelledby="dessert-title" className="mt-14 scroll-mt-28">
              <Heading id="dessert-title" title="Deserti" price={dessertPrice} unit="porcija" />
              <ul className="mt-4 grid gap-x-20 sm:grid-cols-2">
                {desserts.map((d) => (
                  <Dish key={d} name={d} />
                ))}
              </ul>
            </article>

            <div className="mt-14 flex justify-center">
              <Button href="#kontakti" arrow>
                Pasūtīt svētku galdu
              </Button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
