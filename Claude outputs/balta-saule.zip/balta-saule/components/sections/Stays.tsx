import Image from "next/image";
import { images, type Img } from "@/lib/data";
import { Reveal } from "../ui/Reveal";
import { Button } from "../ui/Button";

const moments: { img: Img; time: string; caption: string }[] = [
  { img: images.balcony, time: "Rīts", caption: "Kafija uz balkona starp ziediem" },
  { img: images.room, time: "Diena", caption: "Mājīga istaba ar koka siltumu" },
  { img: images.sauna, time: "Vakars", caption: "Pirts pēc dienas pie jūras" },
  { img: images.tub, time: "Nakts", caption: "Kubls zem zvaigznēm" },
];

/** Nedēļas nogale kā stāsts no rīta līdz naktij. */
export function Stays() {
  return (
    <section id="naktsmitnes" aria-labelledby="stays-title" className="bg-sandwarm py-28 lg:py-36">
      <div className="container-x">
        <div className="grid items-end gap-10 lg:grid-cols-12">
          <Reveal className="lg:col-span-7">
            <p className="font-script text-5xl leading-none text-caramel">Nedēļas nogale pie jūras</p>
            <h2 id="stays-title" className="mt-4 text-[clamp(2.6rem,4.8vw,4.4rem)] font-light leading-[1.05]">
              Palieciet ilgāk. Elpojiet dziļāk.
            </h2>
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5">
            <p className="text-[1.05rem] leading-[1.85] text-ink/80">
              Komfortabli numuri ar siltu, dabīgu noskaņu. Priežu smarža, jūra dažu soļu attālumā, pirts un kubls — lai
              pēc svētkiem vai garas nedēļas varētu atpūsties kā mājās.
            </p>
          </Reveal>
        </div>

        <ul className="mt-16 grid grid-cols-2 gap-4 lg:mt-20 lg:grid-cols-4 lg:gap-6">
          {moments.map((mo, i) => (
            <Reveal as="li" key={mo.time} delay={i * 0.1} className={i % 2 === 1 ? "lg:mt-14" : ""}>
              <figure className="group">
                <div className="relative aspect-[3/4] overflow-hidden rounded-[1rem] shadow-[0_22px_44px_-26px_rgba(58,40,25,0.6)]">
                  <Image
                    src={mo.img.src}
                    alt={mo.img.alt}
                    fill
                    sizes="(min-width: 1024px) 25vw, 50vw"
                    style={{ objectPosition: mo.img.pos }}
                    className="object-cover transition-transform duration-[1.6s] ease-[var(--ease-soft)] group-hover:scale-[1.07]"
                  />
                </div>
                <figcaption className="mt-4">
                  <span className="font-script text-3xl leading-none text-caramel">{mo.time}</span>
                  <span className="mt-1 block text-[0.98rem] text-ink/80">{mo.caption}</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>

        <Reveal className="mt-14 flex justify-center">
          <Button href="#kontakti" arrow>
            Rezervēt naktsmītni
          </Button>
        </Reveal>
      </div>
    </section>
  );
}
