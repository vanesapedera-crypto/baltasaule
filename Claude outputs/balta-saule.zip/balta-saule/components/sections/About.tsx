import Image from "next/image";
import { images, type Img } from "@/lib/data";
import { Reveal } from "../ui/Reveal";

/** Fotogrāfija kā izdrukāta bilde — ar gaišu apmali un vieglu slīpumu. */
function Print({ img, className, sizes, rotate }: { img: Img; className: string; sizes: string; rotate: string }) {
  return (
    <div
      className={`group absolute bg-[#fffaf2] p-2.5 shadow-[0_24px_50px_-22px_rgba(58,40,25,0.55)] transition-transform duration-700 ease-[var(--ease-soft)] hover:rotate-0 hover:scale-[1.02] sm:p-3 ${rotate} ${className}`}
    >
      <div className="relative size-full overflow-hidden">
        <Image src={img.src} alt={img.alt} fill sizes={sizes} className="object-cover" />
      </div>
    </div>
  );
}

export function About() {
  return (
    <section id="par-mums" aria-labelledby="about-title" className="overflow-hidden bg-linen pb-28 pt-8 lg:pb-40">
      <div className="container-x grid items-center gap-20 lg:grid-cols-12 lg:gap-16">
        {/* Foto kolāža */}
        <Reveal className="relative mx-auto h-[34rem] w-full max-w-xl sm:h-[40rem] lg:col-span-6 lg:h-[44rem]">
          <Print img={images.about} rotate="-rotate-2" className="left-[6%] top-0 h-[78%] w-[62%]" sizes="(min-width: 1024px) 28vw, 60vw" />
          <Print img={images.flowers} rotate="rotate-3" className="right-0 top-[12%] h-[34%] w-[46%]" sizes="(min-width: 1024px) 20vw, 45vw" />
          <Print img={images.veranda} rotate="-rotate-1" className="bottom-0 right-[6%] h-[38%] w-[52%]" sizes="(min-width: 1024px) 22vw, 50vw" />
        </Reveal>

        <Reveal delay={0.12} className="lg:col-span-6 lg:pl-8">
          <p className="font-script text-5xl leading-none text-caramel">Mūsu stāsts</p>
          <h2 id="about-title" className="mt-4 text-[clamp(2.6rem,4.6vw,4.2rem)] font-light leading-[1.05]">
            Ģimenes radīta vieta, kur jūtaties kā mājās
          </h2>
          <div className="mt-8 space-y-5 text-[1.05rem] leading-[1.85] text-ink/85">
            <p>
              Tikai dažu soļu attālumā no jūras atrodas Baltā Saule – ģimenes radīta atpūtas vieta, kur valda miers,
              viesmīlība un patiesa māju sajūta. Šeit ikviens var baudīt nesteidzīgu atpūtu vai svinēt dzīves
              nozīmīgākos notikumus kopā ar saviem tuvākajiem.
            </p>
            <p>
              Piedāvājam mājīgas naktsmītnes, plašu svinību zāli līdz 40 viesiem, pirti, kublu un labiekārtotu
              teritoriju, kur priežu mežs satiekas ar jūras tuvumu.
            </p>
            <p>
              Īpašu vietu mūsu stāstā ieņem Omītes virtuve, kuras saimniece Alda jau daudzus gadus gatavo ēdienus ar
              sirds siltumu un rūpību. Svētku organizēšanā palīdz Smaidu darbnīca, bet par dekorācijām rūpējas mūsu otra
              meita.
            </p>
          </div>
          <p className="mt-10 font-script text-4xl text-espresso">Ar sirsnību, Baltās Saules ģimene</p>
        </Reveal>
      </div>
    </section>
  );
}
