"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, m } from "framer-motion";
import { Menu, Phone, X } from "lucide-react";
import { contact, navItems } from "@/lib/data";
import { Logo } from "./ui/Logo";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>("#sakums");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Aktīvās sadaļas izcelšana navigācijā
  useEffect(() => {
    const sections = navItems
      .map((n) => document.querySelector<HTMLElement>(n.href))
      .filter((el): el is HTMLElement => Boolean(el));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => e.isIntersecting && setActive(`#${e.target.id}`));
      },
      { rootMargin: "-45% 0px -50% 0px" },
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const solid = scrolled || open;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-[var(--ease-soft)] ${
        solid
          ? "border-b border-transparent bg-linen/95 py-3 shadow-[0_10px_30px_-20px_rgba(58,40,25,0.4)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent py-6 [text-shadow:0_1px_16px_rgba(33,23,16,0.35)]"
      }`}
    >
      <div className="container-x flex items-center justify-between gap-6">
        <a href="#sakums" aria-label="Baltā Saule — uz sākumu" className="relative z-10">
          <Logo tone={solid ? "dark" : "light"} className="transition-colors duration-500" />
        </a>

        <nav aria-label="Galvenā navigācija" className="hidden xl:block">
          <ul className="flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = active === item.href;
              return (
                <li key={item.href}>
                  <a
                    href={item.href}
                    aria-current={isActive ? "true" : undefined}
                    className={`relative rounded-full px-3.5 py-2 text-[0.84rem] font-medium tracking-wide transition-colors duration-300 ${
                      solid ? "text-espresso hover:text-caramel" : "text-white/90 hover:text-white"
                    } after:absolute after:inset-x-3.5 after:-bottom-0.5 after:h-px after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-500 hover:after:scale-x-100 ${
                      isActive ? "after:scale-x-100" : ""
                    }`}
                  >
                    {item.label}
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#kontakti"
            className={`hidden min-h-12 items-center gap-2 rounded-full px-7 py-3 text-sm font-medium tracking-wide transition-all duration-500 hover:-translate-y-0.5 sm:inline-flex ${
              solid
                ? "bg-caramel text-white hover:bg-caramel-dark"
                : "bg-white text-espresso hover:bg-caramel hover:text-white"
            }`}
          >
            <Phone aria-hidden className="size-4" />
            Sazināties
          </a>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Aizvērt izvēlni" : "Atvērt izvēlni"}
            className={`relative z-10 inline-flex size-12 items-center justify-center rounded-full transition-colors xl:hidden ${
              solid ? "text-ink hover:bg-sand-soft" : "text-white hover:bg-white/10"
            }`}
          >
            {open ? <X className="size-6" /> : <Menu className="size-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <m.div
            id="mobile-menu"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-x-0 top-0 -z-0 h-dvh overflow-y-auto bg-linen px-6 pb-10 pt-28 xl:hidden"
          >
            <nav aria-label="Mobilā navigācija">
              <ul className="flex flex-col divide-y divide-line">
                {navItems.map((item, i) => (
                  <m.li
                    key={item.href}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * i + 0.1, duration: 0.4 }}
                  >
                    <a
                      href={item.href}
                      onClick={() => setOpen(false)}
                      className="flex items-center justify-between py-4 font-serif text-3xl text-espresso transition-colors hover:text-caramel"
                    >
                      {item.label}
                      <span aria-hidden className="text-sm text-sand">
                        0{i + 1}
                      </span>
                    </a>
                  </m.li>
                ))}
              </ul>
            </nav>
            <a
              href={contact.phoneHref}
              className="mt-10 flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-caramel px-7 py-4 text-sm font-medium text-white"
            >
              <Phone aria-hidden className="size-4" />
              Zvanīt {contact.phone}
            </a>
          </m.div>
        )}
      </AnimatePresence>
    </header>
  );
}
