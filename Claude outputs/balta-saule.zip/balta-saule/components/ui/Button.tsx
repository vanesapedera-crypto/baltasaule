import { ArrowRight } from "lucide-react";

type Variant = "primary" | "light" | "ghost";

const styles: Record<Variant, string> = {
  primary:
    "bg-caramel text-white shadow-[0_14px_30px_-14px_rgba(126,84,52,0.8)] hover:bg-caramel-dark hover:shadow-[0_18px_40px_-14px_rgba(126,84,52,0.9)]",
  light: "bg-linen text-wood hover:bg-white",
  ghost: "border border-white/60 text-white hover:bg-white hover:text-wood",
};

type Props = {
  href: string;
  children: React.ReactNode;
  variant?: Variant;
  arrow?: boolean;
  className?: string;
};

export function Button({ href, children, variant = "primary", arrow = false, className = "" }: Props) {
  return (
    <a
      href={href}
      className={`group inline-flex min-h-14 items-center justify-center gap-3 rounded-full px-8 text-[0.95rem] font-medium tracking-wide transition-all duration-500 ease-[var(--ease-soft)] hover:-translate-y-0.5 ${styles[variant]} ${className}`}
    >
      {children}
      {arrow && <ArrowRight aria-hidden className="size-4 transition-transform duration-500 group-hover:translate-x-1" />}
    </a>
  );
}
