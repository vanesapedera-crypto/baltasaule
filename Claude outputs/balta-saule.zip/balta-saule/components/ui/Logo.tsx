type Props = { tone?: "light" | "dark"; className?: string };

export function Logo({ tone = "dark", className = "" }: Props) {
  const color = tone === "light" ? "text-ivory" : "text-espresso";
  return (
    <span className={`inline-flex items-center gap-2 ${color} ${className}`}>
      <svg aria-hidden viewBox="0 0 40 40" className="size-8 shrink-0" fill="none">
        <circle cx="20" cy="22" r="7.5" fill="currentColor" opacity=".9" />
        <g stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" opacity=".75">
          <path d="M20 6v4M8.7 10.7l2.8 2.8M31.3 10.7l-2.8 2.8M4 22h4M32 22h4" />
        </g>
        <path d="M4 32.5c5-2.4 10-2.4 16 0s11 2.4 16 0" stroke="#D8BE96" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
      <span className="font-script text-[2.1rem] leading-none">Baltā Saule</span>
    </span>
  );
}
