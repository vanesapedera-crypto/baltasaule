"use client";

import { m, type Variants } from "framer-motion";

const variants: Variants = {
  hidden: { opacity: 0, y: 22 },
  show: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 1.3, ease: [0.16, 1, 0.3, 1], delay },
  }),
};

type Props = {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "li" | "article" | "figure";
};

/** Fade-in + slide-up, kad elements parādās skatā. */
export function Reveal({ children, className, delay = 0, as = "div" }: Props) {
  const Tag = m[as];
  return (
    <Tag
      className={className}
      variants={variants}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "0px 0px -10% 0px" }}
      custom={delay}
    >
      {children}
    </Tag>
  );
}
