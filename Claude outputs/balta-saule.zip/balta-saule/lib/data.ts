/**
 * Visi mājaslapas satura dati vienuviet.
 * ⚠️ Kontaktinformācija (telefons, e-pasts, adrese, Facebook, darba laiks)
 * ir PAGAIDU vērtības — nomainiet tās pret īstajām pirms publicēšanas.
 */

export const site = {
  name: "Baltā Saule",
  url: "https://www.baltasaule.lv", // TODO: īstais domēns
  tagline: "Atpūta pie jūras • Svinības • Omītes virtuve",
  description:
    "Mājīga vieta, kur jūras tuvums, gardi ēdieni un skaisti svētki kļūst par neaizmirstamām atmiņām.",
};

export const contact = {
  phone: "+371 20 000 000", // TODO
  phoneHref: "tel:+37120000000", // TODO
  email: "info@baltasaule.lv", // TODO
  facebook: "https://www.facebook.com/", // TODO: lapas saite
  address: "Baltā Saule, Latvija", // TODO: precīza adrese
  mapsQuery: "Baltā Saule viesu nams", // TODO: adrese vai koordinātes kartei
  hours: [
    { days: "Pirmdiena – Piektdiena", time: "9:00 – 20:00" }, // TODO
    { days: "Sestdiena – Svētdiena", time: "10:00 – 18:00" }, // TODO
  ],
  hoursNote: "Pasākumi — pēc iepriekšējas vienošanās",
};

export const navItems = [
  { label: "Sākums", href: "#sakums" },
  { label: "Par mums", href: "#par-mums" },
  { label: "Naktsmītnes", href: "#naktsmitnes" },
  { label: "Svinības", href: "#svinibas" },
  { label: "Omītes virtuve", href: "#omites-virtuve" },
  { label: "Galerija", href: "#galerija" },
  { label: "Kontakti", href: "#kontakti" },
] as const;

/** pos — neobligāts CSS object-position attēla kadrējumam, piem. "50% 80%" */
export type Img = { src: string; alt: string; pos?: string };

/**
 * FOTOGRĀFIJAS — katrs foto lapā parādās tikai vienreiz:
 * hero, about, room (Naktsmītnes), hall (Svinības), pies (Omītes virtuve); pārējie — galerijā.
 *
 * FOTOGRĀFIJAS — Baltās Saules īstie foto mapē /public/images.
 * Lai nomainītu attēlu, ievietojiet jaunu failu mapē un mainiet `src` šeit.
 */
export const images = {
  hero: { src: "/images/hero.jpg", alt: "Baltās Saules koka namiņš ar verandu zaļumu ieskautā teritorijā" },
  about: { src: "/images/about.jpg", alt: "Viesi pie ziediem rotātās Baltās Saules ieejas" },
  quote: { src: "/images/celebration-guests.jpg", alt: "Viesi svinībās Baltās Saules zālē" },
  balcony: { src: "/images/balcony.jpg", alt: "Balkons ar puķu podiem un skatu uz zaļumiem" },
  wedding: { src: "/images/wedding.jpg", alt: "Viesi baltās drēbēs svinībās dārzā" },
  pies: { src: "/images/pies.jpg", alt: "Mājās cepti pīrāgi no Omītes virtuves" },
  tubSwing: { src: "/images/tub-swing.jpg", alt: "Kubls un šūpuļkrēsls atpūtas terasē" },
  room: { src: "/images/room.jpg", alt: "Gaiša atpūtas telpa ar koka grīdu un dīvānu" },
  veranda: { src: "/images/veranda.jpg", alt: "Veranda ar ziediem un viesiem", pos: "50% 90%" },
  sauna: { src: "/images/sauna.jpg", alt: "Pirts ieeja ar koka apdari" },
  tub: { src: "/images/tub.jpg", alt: "Kubls pagalmā pie koka mājas" },
  hall: { src: "/images/hall.jpg", alt: "Svinību zāle ar garu, klātu svētku galdu" },
  banquet: { src: "/images/banquet.jpg", alt: "Svinību zāle ar banketa galdiem" },
  table: { src: "/images/table.jpg", alt: "Svētku galds ar ziediem, uzkodām un dzērieniem" },
  flowers: { src: "/images/flowers.jpg", alt: "Baltās Saules zīme starp krāšņiem ziedu podiem" },
} satisfies Record<string, Img>;

export const services = [
  {
    title: "Naktsmītnes",
    text: "Komfortabli numuri ar siltu, dabīgu noskaņu.",
    href: "#naktsmitnes",
  },
  {
    title: "Svinības",
    text: "Kāzas, jubilejas, kristības un uzņēmumu pasākumi.",
    href: "#svinibas",
  },
  {
    title: "Omītes virtuve",
    text: "Banketi, aukstais un siltais galds, salāti, uzkodas, deserti.",
    href: "#omites-virtuve",
  },
  {
    title: "Atpūta",
    text: "Pirts, kubls, teritorija un jūra dažu soļu attālumā.",
    href: "#naktsmitnes",
  },
] as const;

/* ------------------------------ ĒDIENKARTE ------------------------------ */

export const comboPrice = 32;

export const coldTable = {
  title: "Aukstais galds",
  price: 22,
  items: [
    "Gaļas plate",
    "MINI cūkgaļas karbonādes",
    "Vistas filejas ruletīši",
    "Cūkgaļas kotletītes",
    "Vistas fileja sezamā",
    "Fritēti krabīši",
    "Zivs fileja sarkanajā marinādē",
    "Dārzeņu plate ar zaļumu mērcīti",
    "4 veidu salāti pēc izvēles",
  ],
};

export const warmTable = {
  title: "Siltais galds",
  price: 16,
  included: ["Vārīti kartupeļi ar dillītēm", "Baltā siera mērcīte", "Sautēti kāposti"],
  choose: 3,
  mains: [
    "Cūkgaļas karbonāde",
    "Vistas filejas karbonāde",
    "Cūkgaļas kotlete",
    "Vistas kotlete",
    "Pildīts vistas veltnītis",
    "Pildīta kotlete",
    "Cepts vistas šķiņķītis",
    "Pildīts cūkgaļas veltnītis",
    "Cepta zivs fileja",
  ],
};

export const salads: { name: string; price: string }[] = [
  { name: "Gaļas salāti", price: "11" },
  { name: "Rasols", price: "9.50" },
  { name: "Grauzdiņu salāti", price: "12" },
  { name: "Cēzera salāti", price: "12" },
  { name: "Siļķe kažokā", price: "10" },
  { name: "Mēlīšu salāti", price: "13" },
  { name: "Tunča salāti", price: "12" },
  { name: "Grieķu salāti", price: "12" },
  { name: "Siera salāti", price: "11" },
  { name: "Krabju salāti", price: "11.50" },
  { name: "Pupiņu salāti", price: "11" },
  { name: "Vistas BBQ salāti", price: "12" },
  { name: "Vistas salāti ar pupiņām", price: "12.50" },
  { name: "Liellopu gaļas salāti", price: "14" },
  { name: "Vistas salāti ar ananāsiem", price: "11" },
  { name: "Šampinjonu salāti", price: "11.50" },
];

export const appetizers: { name: string; price: string }[] = [
  { name: "Pildīts lavašs", price: "22–25" },
  { name: "Siera plate", price: "22" },
  { name: "Zivju plate", price: "19" },
  { name: "Dārzeņu plate", price: "13" },
  { name: "Zivs sarkanajā marinādē", price: "19" },
  { name: "Gaļas plate", price: "19" },
];

export const dessertPrice = "3.50";

export const desserts = [
  "Zemeņu krēms ar vaniļas mērci",
  "Šokolādes krēms ar ogu mērci",
  "Panna cotta ar zemenēm",
  "Kafijas krēms ar ogu mērci",
  "Auzu pārslu kraukšķis",
  "Abavas sniegs ar ķīseli",
  "Oreo cepumu krēms ar ķīseli",
  "Biezpiena krēms ar ķīseli",
  "Maizes zupa ar putukrējumu",
  "Šokolādes krēms ar vaniļas mērci",
];

/* ------------------------------- GALERIJA ------------------------------- */

export const galleryCategories = [
  "Visi",
  "Naktsmītnes",
  "Svinības",
  "Omītes virtuve",
  "Pirts",
  "Kubuls",
  "Teritorija",
] as const;

export type GalleryCategory = Exclude<(typeof galleryCategories)[number], "Visi">;

/** w/h — attēla izmēri pikseļos (dabiskajām proporcijām masonry galerijā) */
export type GalleryItem = Img & { category: GalleryCategory; w: number; h: number };

const g = (img: Img, category: GalleryCategory, w: number, h: number): GalleryItem => ({ ...img, category, w, h });

export const gallery: GalleryItem[] = [
  g(images.wedding, "Svinības", 960, 1440),
  g(images.tub, "Kubuls", 1440, 960),
  g(images.table, "Svinības", 750, 1000),
  g(images.flowers, "Teritorija", 1024, 683),
  g(images.sauna, "Pirts", 1536, 2048),
  g(images.banquet, "Omītes virtuve", 1024, 683),
  g({ src: "/images/balloons.jpg", alt: "Svētku zāle ar baloniem un gaismas zīmi" }, "Svinības", 750, 1000),
  g({ src: "/images/bike.jpg", alt: "Ar ziediem rotāts velosipēds teritorijā" }, "Teritorija", 1024, 683),
  g(images.quote, "Svinības", 2048, 1365),
  g(images.tubSwing, "Kubuls", 1024, 683),
  g({ src: "/images/lanterns.jpg", alt: "Laternas un šūpuļkrēsls pie verandas loga" }, "Teritorija", 1024, 683),
  g(images.balcony, "Naktsmītnes", 1536, 2048),
  g({ src: "/images/decor.jpg", alt: "Svētku dekori ar lampiņām un sausziediem" }, "Svinības", 1024, 683),
  g(images.veranda, "Teritorija", 1440, 960),
];
