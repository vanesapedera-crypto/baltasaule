import type { Metadata, Viewport } from "next";
import { Allura, Cormorant_Garamond, Inter } from "next/font/google";
import { MotionProvider } from "@/components/ui/MotionProvider";
import { contact, site } from "@/lib/data";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin", "latin-ext"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin", "latin-ext"],
  variable: "--font-inter",
  display: "swap",
});

const allura = Allura({
  subsets: ["latin", "latin-ext"],
  weight: "400",
  variable: "--font-allura",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "Baltā Saule — viesu nams, svinības un Omītes virtuve pie jūras",
    template: "%s | Baltā Saule",
  },
  description:
    "Baltā Saule — ģimenes viesu nams dažu soļu attālumā no jūras. Mājīgas naktsmītnes, svinību zāle līdz 40 viesiem, pirts, kubls un Omītes virtuves banketi kāzām, jubilejām un kristībām.",
  keywords: [
    "viesu nams pie jūras",
    "svinību zāle",
    "kāzu vieta",
    "jubileju svinēšana",
    "kristības",
    "banketi",
    "aukstais galds",
    "pirts un kubls",
    "Baltā Saule",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "lv_LV",
    url: site.url,
    siteName: site.name,
    title: "Baltā Saule — atpūta pie jūras, svinības un Omītes virtuve",
    description: site.description,
    images: [{ url: "/images/og.jpg", width: 1200, height: 630, alt: "Baltā Saule pie jūras" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Baltā Saule",
    description: site.description,
    images: ["/images/og.jpg"],
  },
  robots: { index: true, follow: true },
  formatDetection: { telephone: true, email: true },
};

export const viewport: Viewport = {
  themeColor: "#FAF7F2",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LodgingBusiness",
  name: site.name,
  description: metadata.description,
  url: site.url,
  image: `${site.url}/images/hero.jpg`,
  telephone: contact.phone,
  email: contact.email,
  address: { "@type": "PostalAddress", streetAddress: contact.address, addressCountry: "LV" },
  sameAs: [contact.facebook],
  amenityFeature: [
    { "@type": "LocationFeatureSpecification", name: "Pirts", value: true },
    { "@type": "LocationFeatureSpecification", name: "Kubls", value: true },
    { "@type": "LocationFeatureSpecification", name: "Svinību zāle līdz 40 viesiem", value: true },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="lv" className={`${cormorant.variable} ${inter.variable} ${allura.variable}`}>
      <body>
        <a
          href="#saturs"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-caramel focus:px-5 focus:py-3 focus:text-sm focus:text-white"
        >
          Pāriet uz saturu
        </a>
        <MotionProvider>{children}</MotionProvider>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
