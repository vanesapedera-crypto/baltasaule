import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { About } from "@/components/sections/About";
import { Celebrations } from "@/components/sections/Celebrations";
import { Interlude } from "@/components/sections/Interlude";
import { Stays } from "@/components/sections/Stays";
import { Kitchen } from "@/components/sections/Kitchen";
import { Gallery } from "@/components/sections/Gallery";
import { Contact } from "@/components/sections/Contact";

/**
 * Emocijas vispirms: silts hero → trīs ielūgumi (svinēt, atpūsties, nogaršot)
 * → ģimenes stāsts → svinības → atmosfēras foto → nedēļas nogale → Omītes virtuve
 * → galerija → ielūgums sazināties.
 */
export default function HomePage() {
  return (
    <>
      <Header />
      <main id="saturs">
        <Hero />
        <Services />
        <About />
        <Celebrations />
        <Interlude />
        <Stays />
        <Kitchen />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
